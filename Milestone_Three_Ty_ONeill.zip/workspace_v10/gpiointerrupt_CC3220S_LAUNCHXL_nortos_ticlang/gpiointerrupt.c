/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* */
#include <ti/drivers/Timer.h>

Timer_Handle timer0;

typedef enum {
    STATE_IDLE,
    // States for "S" in SOS
    STATE_S_DOT_1, STATE_S_DOT_1_ON, STATE_S_DOT_1_PAUSE,
    STATE_S_DOT_2, STATE_S_DOT_2_ON, STATE_S_DOT_2_PAUSE,
    STATE_S_DOT_3, STATE_S_DOT_3_ON, STATE_S_DOT_3_PAUSE,
    // States for "O" in SOS
    STATE_SOS_O_DASH_1, STATE_SOS_O_DASH_1_ON, STATE_SOS_O_DASH_1_PAUSE,
    STATE_SOS_O_DASH_2, STATE_SOS_O_DASH_2_ON, STATE_SOS_O_DASH_2_PAUSE,
    STATE_SOS_O_DASH_3, STATE_SOS_O_DASH_3_ON, STATE_SOS_O_DASH_3_PAUSE,
    // States for second "S" in SOS
    STATE_S_DOT_1_ROUND_2, STATE_S_DOT_1_ON_ROUND_2, STATE_S_DOT_1_PAUSE_ROUND_2,
    STATE_S_DOT_2_ROUND_2, STATE_S_DOT_2_ON_ROUND_2, STATE_S_DOT_2_PAUSE_ROUND_2,
    STATE_S_DOT_3_ROUND_2, STATE_S_DOT_3_ON_ROUND_2, STATE_S_DOT_3_PAUSE_ROUND_2,
    // States for "O" in OK
    STATE_OK_O_DASH_1, STATE_OK_O_DASH_1_ON, STATE_OK_O_DASH_1_PAUSE,
    STATE_OK_O_DASH_2, STATE_OK_O_DASH_2_ON, STATE_OK_O_DASH_2_PAUSE,
    STATE_OK_O_DASH_3, STATE_OK_O_DASH_3_ON, STATE_OK_O_DASH_3_PAUSE,
    // States for "K" in OK
    STATE_OK_K_DASH_1, STATE_OK_K_DASH_1_ON, STATE_OK_K_DASH_1_PAUSE,
    STATE_OK_K_DOT, STATE_OK_K_DOT_ON, STATE_OK_K_DOT_PAUSE,
    STATE_OK_K_DASH_2, STATE_OK_K_DASH_2_ON, STATE_OK_K_DASH_2_PAUSE,
    // Pause and completion status
    STATE_WORD_PAUSE, STATE_WORD_PAUSE_ON,
    STATE_MESSAGE_COMPLETE
} State;

State currentState = STATE_IDLE;
volatile bool toggleMessage = false;
bool isSOS = true; // Start with SOS
static int durationCounter = 0;


void timerCallback(Timer_Handle myHandle, int_fast16_t status) {

    switch(currentState) {
        // Initial state, start with either SOS or OK
        case STATE_IDLE:
            if(isSOS) {
                currentState = STATE_S_DOT_1;
            } else {
                currentState = STATE_OK_O_DASH_1;
            }
            break;

        // "S" in SOS (Dot dot dot)
        case STATE_S_DOT_1:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            durationCounter = 1;
            currentState = STATE_S_DOT_1_ON;
            break;

        case STATE_S_DOT_1_ON:
            if (durationCounter >= 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                currentState = STATE_S_DOT_1_PAUSE;
            }
            break;

        case STATE_S_DOT_1_PAUSE:
            currentState = STATE_S_DOT_2;
            break;

        case STATE_S_DOT_2:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            durationCounter = 1;
            currentState = STATE_S_DOT_2_ON;
            break;

        case STATE_S_DOT_2_ON:
            if (durationCounter >= 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                currentState = STATE_S_DOT_2_PAUSE;
            }
            break;

        case STATE_S_DOT_2_PAUSE:
            currentState = STATE_S_DOT_3;
            break;

        case STATE_S_DOT_3:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            durationCounter = 1;
            currentState = STATE_S_DOT_3_ON;
            break;

        case STATE_S_DOT_3_ON:
            if (durationCounter >= 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                currentState = STATE_S_DOT_3_PAUSE;
            }
            break;

        case STATE_S_DOT_3_PAUSE:
            currentState = STATE_SOS_O_DASH_1;
            break;

        // "O" in SOS (Dash Dash Dash)
        case STATE_SOS_O_DASH_1:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;  // Dash duration: 3 timer periods (1500 ms)
            currentState = STATE_SOS_O_DASH_1_ON;
            break;

        case STATE_SOS_O_DASH_1_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_SOS_O_DASH_1_PAUSE;
            }
            break;

        case STATE_SOS_O_DASH_1_PAUSE:
            currentState = STATE_SOS_O_DASH_2;
            break;

        case STATE_SOS_O_DASH_2:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;
            currentState = STATE_SOS_O_DASH_2_ON;
            break;

        case STATE_SOS_O_DASH_2_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_SOS_O_DASH_2_PAUSE;
            }
            break;

        case STATE_SOS_O_DASH_2_PAUSE:
            currentState = STATE_SOS_O_DASH_3;
            break;

        case STATE_SOS_O_DASH_3:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;
            currentState = STATE_SOS_O_DASH_3_ON;
            break;

        case STATE_SOS_O_DASH_3_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_SOS_O_DASH_3_PAUSE;
            }
            break;

        case STATE_SOS_O_DASH_3_PAUSE:
            currentState = STATE_S_DOT_1_ROUND_2;
            break;

        // Round Two "S" of SOS
        case STATE_S_DOT_1_ROUND_2:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            durationCounter = 1;
            currentState = STATE_S_DOT_1_ON_ROUND_2;
            break;

        case STATE_S_DOT_1_ON_ROUND_2:
            if (durationCounter >= 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                currentState = STATE_S_DOT_1_PAUSE_ROUND_2;
            }
            break;

        case STATE_S_DOT_1_PAUSE_ROUND_2:
            currentState = STATE_S_DOT_2_ROUND_2;
            break;

        case STATE_S_DOT_2_ROUND_2:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            durationCounter = 1;
            currentState = STATE_S_DOT_2_ON_ROUND_2;
            break;

        case STATE_S_DOT_2_ON_ROUND_2:
            if (durationCounter >= 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                currentState = STATE_S_DOT_2_PAUSE_ROUND_2;
            }
            break;

        case STATE_S_DOT_2_PAUSE_ROUND_2:
            currentState = STATE_S_DOT_3_ROUND_2;
            break;

        case STATE_S_DOT_3_ROUND_2:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            durationCounter = 1;
            currentState = STATE_S_DOT_3_ON_ROUND_2;
            break;

        case STATE_S_DOT_3_ON_ROUND_2:
            if (durationCounter >= 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                currentState = STATE_S_DOT_3_PAUSE_ROUND_2;
             }
             break;

        case STATE_S_DOT_3_PAUSE_ROUND_2:
            currentState = STATE_WORD_PAUSE;
            break;

        // Case for when SOS is completed?

        // Handle "OK" in Morse Code: Dash Dot Dash for "O" and "K"
        case STATE_OK_O_DASH_1:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;  // Dash duration
            currentState = STATE_OK_O_DASH_1_ON;
            break;

        case STATE_OK_O_DASH_1_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_OK_O_DASH_1_PAUSE;
            }
            break;

        case STATE_OK_O_DASH_1_PAUSE:
            currentState = STATE_OK_O_DASH_2;
            break;

        case STATE_OK_O_DASH_2:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;
            currentState = STATE_OK_O_DASH_2_ON;
            break;

        case STATE_OK_O_DASH_2_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_OK_O_DASH_2_PAUSE;
            }
            break;

        case STATE_OK_O_DASH_2_PAUSE:
            currentState = STATE_OK_O_DASH_3;
            break;

        case STATE_OK_O_DASH_3:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;
            currentState = STATE_OK_O_DASH_3_ON;
            break;

        case STATE_OK_O_DASH_3_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_OK_O_DASH_3_PAUSE;
            }
            break;

                case STATE_OK_O_DASH_3_PAUSE:
                    currentState = STATE_OK_K_DASH_1;
                    break;

        // "K" in OK
        case STATE_OK_K_DASH_1:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;  // Dash duration
            currentState = STATE_OK_K_DASH_1_ON;
            break;

        case STATE_OK_K_DASH_1_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_OK_K_DASH_1_PAUSE;
            }
            break;

        case STATE_OK_K_DASH_1_PAUSE:
            currentState = STATE_OK_K_DOT;
            break;

        case STATE_OK_K_DOT:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            durationCounter = 1;
            currentState = STATE_OK_K_DOT_ON;
            break;

        case STATE_OK_K_DOT_ON:
            if (durationCounter >= 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                currentState = STATE_OK_K_DOT_PAUSE;
            }
            break;

        case STATE_OK_K_DOT_PAUSE:
            currentState = STATE_OK_K_DASH_2;
            break;

        case STATE_OK_K_DASH_2:
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            durationCounter = 3;
            currentState = STATE_OK_K_DASH_2_ON;
            break;

        case STATE_OK_K_DASH_2_ON:
            if (--durationCounter == 0) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                currentState = STATE_OK_K_DASH_2_PAUSE;
            }
            break;

        case STATE_OK_K_DASH_2_PAUSE:
            currentState = STATE_WORD_PAUSE;
            break;

        // Handle word pause (7 units)
        case STATE_WORD_PAUSE:
            durationCounter = 7;  // Word pause duration (3500 ms)
            currentState = STATE_WORD_PAUSE_ON;
            break;

        case STATE_WORD_PAUSE_ON:
            if (--durationCounter == 0) {
                currentState = STATE_MESSAGE_COMPLETE;
            }
            break;

        // Complete message and toggle if button pressed
        case STATE_MESSAGE_COMPLETE:
            if (toggleMessage) {
                isSOS = !isSOS;  // Toggle between SOS and OK
                toggleMessage = false;
            }
            currentState = STATE_IDLE;
            break;

        default:
            currentState = STATE_IDLE;
            break;
    }
}

void initTimer(void) {

    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
    /* Failed to initialized timer */
    while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
    /* Failed to start timer */
    while (1) {}
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* Toggle an LED */
    //GPIO_toggle(CONFIG_GPIO_LED_0);
    toggleMessage = true;

}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* Toggle an LED */
    GPIO_toggle(CONFIG_GPIO_LED_1);
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */

    /* Initialize Timer */
    initTimer();

    /* Initialize State Machine */
    currentState = STATE_IDLE;

    //    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1)
    //    {
    //        /* Configure BUTTON1 pin */
    //        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    //
    //        /* Install Button callback */
    //        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
    //        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    //    }

    return (NULL);
}
